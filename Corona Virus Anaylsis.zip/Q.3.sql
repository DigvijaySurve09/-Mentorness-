-- Q3. Check total number of rows
SELECT 
    COUNT(*) AS total_rows
FROM 
    coronadatabase.`corona virus dataset`;
