-- Q6. Monthly average for confirmed, deaths, recovered
SELECT 
    DATE_FORMAT(Date, '%Y-%m') AS month,
    AVG(confirmed) AS average_confirmed,
    AVG(deaths) AS average_deaths,
    AVG(recovered) AS average_recovered
FROM `corona virus dataset`
GROUP BY DATE_FORMAT(Date, '%Y-%m');
