-- Q4. Check what is start_date and end_date
SELECT 
    MIN(Date) AS min_start_date,
    MAX(Date) AS max_end_date
FROM 
    coronadatabase.`corona virus dataset`;
