-- Q8. Minimum values for confirmed, deaths, recovered per year
SELECT 
    YEAR(Date) AS year,
    MIN(confirmed) AS min_confirmed,
    MIN(deaths) AS min_deaths,
    MIN(recovered) AS min_recovered
FROM `corona virus dataset`
GROUP BY YEAR(Date)
ORDER BY 'Year';
