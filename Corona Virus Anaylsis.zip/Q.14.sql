-- Q14. Country having highest number of confirmed cases
SELECT 'Country/Region', MAX(confirmed) AS highest_confirmed_cases
FROM `corona virus dataset`;
