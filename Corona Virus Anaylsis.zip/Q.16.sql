SELECT `Country/Region`, recovered
FROM `corona virus dataset`
ORDER BY recovered DESC
LIMIT 5;
