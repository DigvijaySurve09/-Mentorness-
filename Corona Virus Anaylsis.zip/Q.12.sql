-- Q12. Spread of coronavirus with respect to death cases per month
SELECT 
    YEAR(`Date`) AS Year,
    MONTH(`Date`) AS Month,
    SUM(deaths) AS TotalDeaths,
    AVG(deaths) AS AverageDeaths,
    VARIANCE(deaths) AS DeathsVariance,
    STDDEV(deaths) AS DeathsStdDev
FROM 
    `corona virus dataset`
WHERE
    `Date` IS NOT NULL
GROUP BY 
    YEAR(`Date`),
    MONTH(`Date`)
ORDER BY 
    Year, 
    Month;
