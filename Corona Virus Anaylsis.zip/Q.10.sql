-- Q10. Total number of cases of confirmed, deaths, recovered each month
SELECT 
    DATE_FORMAT(Date, '%Y-%m') AS month,
    SUM(confirmed) AS total_confirmed,
    SUM(deaths) AS total_deaths,
    SUM(recovered) AS total_recovered
FROM `corona virus dataset`
GROUP BY DATE_FORMAT(Date, '%Y-%m');
