-- Q11. Spread of coronavirus with respect to confirmed cases
SELECT 
    SUM(confirmed) AS total_confirmed_cases,
    AVG(confirmed) AS average_confirmed_cases,
    VARIANCE(confirmed) AS confirmed_variance,
    STDDEV(confirmed) AS confirmed_stdev
FROM `corona virus dataset`;