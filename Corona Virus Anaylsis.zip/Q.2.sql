-- Q2. Update NULL values with zeros
START TRANSACTION;
UPDATE `corona virus dataset`
SET 
Province = COALESCE(province, 0),
'Country/Region' = COALESCE('Country/Region', 0),
Latitude = COALESCE(Latitude, 0),
Longitude= COALESCE(Longitude, 0),
Date= COALESCE(Date, 0),
    confirmed = COALESCE(confirmed, 0),
    deaths = COALESCE(deaths, 0),
    recovered = COALESCE(recovered, 0)
WHERE
    confirmed IS NULL OR deaths IS NULL OR recovered IS NULL;

COMMIT;
