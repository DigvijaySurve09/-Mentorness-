SELECT 
YEAR(Date)AS year,
COUNT(DISTINCT MONTH(Date))AS num_months
FROM
 coronadatabase.`corona virus dataset`
 GROUP BY
 YEAR(Date);