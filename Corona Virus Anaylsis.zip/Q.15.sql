-- Q15. Country having lowest number of death cases
SELECT `Country/Region`, deaths AS lowest_death_cases
FROM `corona virus dataset`
ORDER BY deaths ASC
LIMIT 1;
