SELECT 
    month,
    COALESCE((SELECT confirmed 
              FROM `corona virus dataset` d2 
              WHERE DATE_FORMAT(d2.Date, '%Y-%m') = month 
              GROUP BY confirmed 
              ORDER BY COUNT(*) DESC 
              LIMIT 1), 'No data') AS most_frequent_confirmed,
    COALESCE((SELECT deaths 
              FROM `corona virus dataset` d3 
              WHERE DATE_FORMAT(d3.Date, '%Y-%m') = month 
              GROUP BY deaths 
              ORDER BY COUNT(*) DESC 
              LIMIT 1), 'No data') AS most_frequent_deaths,
    COALESCE((SELECT recovered 
              FROM `corona virus dataset` d4 
              WHERE DATE_FORMAT(d4.Date, '%Y-%m') = month 
              GROUP BY recovered 
              ORDER BY COUNT(*) DESC 
              LIMIT 1), 'No data') AS most_frequent_recovered
FROM (
    SELECT DATE_FORMAT(Date, '%Y-%m') AS month
    FROM `corona virus dataset`
    GROUP BY DATE_FORMAT(Date, '%Y-%m')
) AS months;
