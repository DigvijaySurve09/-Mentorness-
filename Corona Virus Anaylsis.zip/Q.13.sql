-- Q13. Spread of coronavirus with respect to recovered cases
SELECT 
    SUM(recovered) AS total_recovered,
    AVG(recovered) AS average_recovered,
    VARIANCE(recovered) AS recovered_variance,
    STDDEV(recovered) AS recovered_stdev
FROM `corona virus dataset`;